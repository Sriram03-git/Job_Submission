package com.application.tracker.job_application_tracker_api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JobApplicationTrackerApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(JobApplicationTrackerApiApplication.class, args);
	}

}
